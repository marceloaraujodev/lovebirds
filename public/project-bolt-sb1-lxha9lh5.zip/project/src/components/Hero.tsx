import React from 'react';
import { Search } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative h-[600px]">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1582407947304-fd86f028f716?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      </div>
      
      <div className="relative container mx-auto px-4 h-full flex flex-col justify-center items-center text-white">
        <h1 className="text-4xl md:text-6xl font-bold text-center mb-6">
          Encontre seu Imóvel em Balneário Camboriú
        </h1>
        <p className="text-xl md:text-2xl text-center mb-12">
          Os melhores imóveis da região com as melhores condições
        </p>
        
        <div className="w-full max-w-4xl bg-white rounded-lg shadow-xl p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <select className="flex-1 p-3 border rounded-lg">
              <option>Comprar</option>
              <option>Alugar</option>
            </select>
            <select className="flex-1 p-3 border rounded-lg">
              <option>Apartamento</option>
              <option>Casa</option>
              <option>Terreno</option>
            </select>
            <input 
              type="text" 
              placeholder="Localização" 
              className="flex-1 p-3 border rounded-lg"
            />
            <button className="bg-blue-900 text-white px-8 py-3 rounded-lg flex items-center justify-center gap-2">
              <Search size={20} />
              <span>Buscar</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}