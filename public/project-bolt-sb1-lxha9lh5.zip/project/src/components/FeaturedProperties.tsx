import React from 'react';
import { Bath, BedDouble, Maximize } from 'lucide-react';

const properties = [
  {
    id: 1,
    title: "Apartamento de Luxo",
    location: "Centro, Balneário Camboriú",
    price: "R$ 1.200.000",
    image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    beds: 3,
    baths: 2,
    area: 120
  },
  {
    id: 2,
    title: "Cobertura Duplex",
    location: "Barra Sul, Balneário Camboriú",
    price: "R$ 2.500.000",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    beds: 4,
    baths: 3,
    area: 200
  },
  {
    id: 3,
    title: "Apartamento Vista Mar",
    location: "Pioneiros, Balneário Camboriú",
    price: "R$ 950.000",
    image: "https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    beds: 2,
    baths: 2,
    area: 85
  }
];

export default function FeaturedProperties() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Imóveis em Destaque</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {properties.map((property) => (
            <div key={property.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="relative h-64">
                <img 
                  src={property.image} 
                  alt={property.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{property.title}</h3>
                <p className="text-gray-600 mb-4">{property.location}</p>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-2xl font-bold text-blue-900">{property.price}</span>
                </div>
                
                <div className="flex justify-between text-gray-600">
                  <div className="flex items-center gap-1">
                    <BedDouble size={20} />
                    <span>{property.beds} quartos</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Bath size={20} />
                    <span>{property.baths} banheiros</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Maximize size={20} />
                    <span>{property.area}m²</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}