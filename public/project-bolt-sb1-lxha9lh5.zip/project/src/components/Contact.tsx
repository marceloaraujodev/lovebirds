import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

export default function Contact() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Entre em Contato</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <form className="space-y-6">
                <div>
                  <label className="block text-gray-700 mb-2">Nome</label>
                  <input 
                    type="text" 
                    className="w-full p-3 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Email</label>
                  <input 
                    type="email" 
                    className="w-full p-3 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Mensagem</label>
                  <textarea 
                    className="w-full p-3 border rounded-lg h-32"
                  ></textarea>
                </div>
                <button className="w-full bg-blue-900 text-white py-3 rounded-lg hover:bg-blue-800">
                  Enviar Mensagem
                </button>
              </form>
            </div>
            
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-4">Informações de Contato</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Phone className="text-blue-900" />
                    <span>(47) 3366-5555</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="text-blue-900" />
                    <span>contato@felicita.com.br</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="text-blue-900" />
                    <span>Av. Brasil, 1000 - Centro, Balneário Camboriú - SC</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-4">Horário de Funcionamento</h3>
                <p className="text-gray-600">
                  Segunda a Sexta: 9h às 18h<br />
                  Sábado: 9h às 13h
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}