import React from 'react';
import { Search, Menu, Phone } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-8">
            <h1 className="text-2xl font-bold text-blue-900">Felicita</h1>
            <nav className="hidden md:flex space-x-6">
              <a href="#" className="text-gray-600 hover:text-blue-900">Início</a>
              <a href="#" className="text-gray-600 hover:text-blue-900">Comprar</a>
              <a href="#" className="text-gray-600 hover:text-blue-900">Alugar</a>
              <a href="#" className="text-gray-600 hover:text-blue-900">Lançamentos</a>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <button className="hidden md:flex items-center space-x-2 text-blue-900">
              <Phone size={20} />
              <span>(47) 3366-5555</span>
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Search size={20} />
            </button>
            <button className="md:hidden p-2 hover:bg-gray-100 rounded-full">
              <Menu size={20} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}